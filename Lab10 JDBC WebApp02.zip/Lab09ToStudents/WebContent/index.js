$(document).ready( function () {
    $('#myTable').DataTable({
                "sPaginationType": "full_numbers",
                "bJQueryUI": true
            });
          });


