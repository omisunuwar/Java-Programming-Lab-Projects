package unl.cse.music;

public class DatabaseInfo {

	public static final String url = "jdbc:mysql://127.0.0.1/lab8schema?characterEncoding=latin1"; 
//	public static final String url = "jdbc:mysql://127.0.0.1/lab8schema?autoReconnect=true&useSSL=false";
	public static final String username = "root";
	public static final String password = "MyOracle422!";
	
	
	//useSSL=false to fix 500 internal server error java.sql.SQLNonTransientConnectionException: 
	//Cannot open file:/Users/omisunuwar/glassfish5/glassfish/domains/domain1/config/keystore.jks 
	//[Keystore was tampered with, or password was incorrect]
	

}
