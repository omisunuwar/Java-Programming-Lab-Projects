package unl.cse.music;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AlbumBean {

	@SuppressWarnings("deprecation")
	public Album getDetailedAlbum(int albumId) {

		Album a = new Album();
		Band b = new Band();

		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance(); //Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		} catch (InstantiationException e) {
			System.out.println("InstantiationException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (IllegalAccessException e) {
			System.out.println("IllegalAccessException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
		Connection conn = null;

		try {
			conn = DriverManager.getConnection(DatabaseInfo.url, DatabaseInfo.username, DatabaseInfo.password);
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		

		String query = "SELECT * from Albums a JOIN Bands b on a.BandID = b.BandID WHERE a.AlbumID = ?";
		
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conn.prepareStatement(query);
			ps.setInt(1, albumId);
			rs = ps.executeQuery();
			if(rs.next()) {
				a.setAlbumId(rs.getInt("a.AlbumID"));
				a.setAlbumNumber(rs.getInt("a.AlbumNumber"));
				a.setTitle(rs.getString("a.AlbumTitle"));
				a.setYear(rs.getInt("a.AlbumYear"));
//				Band b = new Band();
				b.setBandId(rs.getInt("b.BandID"));
				b.setName(rs.getString("b.BandName"));
				a.setBand(b);
			}
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
		//now get the song titles
		query = "SELECT SongTitle,TrackLength FROM AlbumSongs a JOIN Songs s ON a.SongID = s.SongId WHERE a.AlbumID = ? ORDER BY TrackNumber";
		
		try {
			ps = conn.prepareStatement(query);
			ps.setInt(1, albumId);
			rs = ps.executeQuery();
			while(rs.next()) {
				a.getSongTitles().add(rs.getString("SongTitle") + " (" + rs.getString("TrackLength") + "s)");
			}
			rs.close();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}		
		try {
			if(rs != null && !rs.isClosed())
				rs.close();
			if(ps != null && !ps.isClosed())
				ps.close();
			if(conn != null && !conn.isClosed())
				conn.close();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}

		return a;
	}
	
	@SuppressWarnings("deprecation")
	public List<Album> getAlbums() {
		
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (InstantiationException e) {
			System.out.println("InstantiationException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (IllegalAccessException e) {
			System.out.println("IllegalAccessException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
		Connection conn = null;

		try {
			conn = DriverManager.getConnection(DatabaseInfo.url, DatabaseInfo.username, DatabaseInfo.password);
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		

		String query = "SELECT * from Albums a JOIN Bands b on a.BandID = b.BandID ORDER BY a.BandID,a.AlbumNumber";
		
		List<Album> albums = new ArrayList<Album>();

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();
			while(rs.next()) {
				Album a = new Album();
				a.setAlbumId(rs.getInt("a.AlbumID"));
				a.setAlbumNumber(rs.getInt("a.AlbumNumber"));
				a.setTitle(rs.getString("a.AlbumTitle"));
				a.setYear(rs.getInt("a.AlbumYear"));
				Band b = new Band();
				b.setBandId(rs.getInt("b.BandID"));
				b.setName(rs.getString("b.BandName"));
				a.setBand(b);
				albums.add(a);
			}
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
		try {
			if(rs != null && !rs.isClosed())
				rs.close();
			if(ps != null && !ps.isClosed())
				ps.close();
			if(conn != null && !conn.isClosed())
				conn.close();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		return albums;
	}
	
	public static void main(String[] args ) {
		
		AlbumBean ab = new AlbumBean();
		Album a = ab.getDetailedAlbum(1);
		System.out.println("Detailed Album: ");
		System.out.println("Title: "+a.getTitle());
		
		for(String songTitle : a.getSongTitles()) {
			System.out.println("\tTracktitle: "+songTitle);
		}
		
		for(Album al: ab.getAlbums()) {
			System.out.println("\n"+al.getTitle());
			Band b = al.getBand();
			System.out.println("\n BandName: "+b.getName());
		}
	} 
}
