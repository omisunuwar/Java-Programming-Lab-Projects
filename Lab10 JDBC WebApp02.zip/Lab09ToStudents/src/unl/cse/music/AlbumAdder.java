package unl.cse.music;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AlbumAdder {

	private String  albumTitle;
	private String  bandName;
	private String albumYear;
	private String albumNumber;
	
	public AlbumAdder(String albumTitle, String bandName, String albumYear, String albumNumber) {
		this.setAlbumTitle(albumTitle);
		this.setBandName(bandName);  
		this.setAlbumYear(albumYear); 
		this.setAlbumNumber(albumNumber);
	}

	/**
	 * Adds the album (and band if necessary) to the database and returns true if the insert was
	 * successful, false otherwise.
	 * @return
	 */
	public boolean AddAlbumToDatabase() {

		//TODO: implement this method!
		
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance(); // JDBC driver name
		} catch (InstantiationException e) {
			System.out.println("InstantiationException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (IllegalAccessException e) {
			System.out.println("IllegalAccessException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}

		Connection conn = null;

		try {
			conn = DriverManager.getConnection(DatabaseInfo.url, DatabaseInfo.username, DatabaseInfo.password); // Connecting
																												// to
																												// Database
																												// url
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
		String query = "SELECT * from Bands where BandName = ?";
		PreparedStatement ps = null;
		ResultSet rs = null;
		Band b = new Band();
		
		try {
			ps = conn.prepareStatement(query);
			ps.setString(1, bandName);
			rs = ps.executeQuery();
			if (rs.next()) {
				b.setBandId(rs.getInt("BandID"));
			}
			
			else {
				query = "INSERT into Bands(BandName) values(?)";
				ps =conn.prepareStatement(query);
				ps.setString(1, bandName);
				//rs.next();
			    ps.executeUpdate();	
			    
			    query = "SELECT * from Bands where BandName = ?";
			    ps = conn.prepareStatement(query);
			    ps.setString(1, bandName);
			    rs = ps.executeQuery();
			    b.setBandId(rs.getInt("BandID"));
				
			}
			
			query = "SELECT * from Albums where AlbumTitle=? and BandID=? and AlbumNumber=? and AlbumYear=?";
			ps = conn.prepareStatement(query);
			ps.setString(1, albumTitle);
			ps.setInt(2, b.getBandId());
			ps.setString(3, albumNumber);
			ps.setString(4, albumYear);
			rs = ps.executeQuery();
			if(rs.next()) {
				System.out.println("Entry already exits in the Albums table");
				//return false;
			}else {
				query = "INSERT into Albums(AlbumTitle, BandID, AlbumYear, AlbumNumber) values(?, ?, ?, ?)";
				ps = conn.prepareStatement(query);
				ps.setString(1, albumTitle);
				ps.setInt(2, b.getBandId());
				ps.setString(3, albumYear);
				ps.setString(4, albumNumber);
				ps.executeUpdate();
				System.out.println("Entry sucessfully inserted into Albums table");
			}
			
		} catch(SQLException e) {
			System.out.println("SQL Exception: ");
			e.printStackTrace();
			throw new RuntimeException(e);
			
		} 
		
		try {
			if(rs != null && !rs.isClosed())
				rs.close();
			if(ps != null && !ps.isClosed())
				ps.close();
			if(conn != null && !conn.isClosed())
				conn.close();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
		
		return true;
	}

	public String getAlbumTitle() {
		return albumTitle;
	}

	public void setAlbumTitle(String albumTitle) {
		this.albumTitle = albumTitle;
	}

	public String getBandName() {
		return bandName;
	}

	public void setBandName(String bandName) {
		this.bandName = bandName;
	}

	public String getAlbumYear() {
		return albumYear;
	}

	public void setAlbumYear(String albumYear) {
		this.albumYear = albumYear;
	}

	public String getAlbumNumber() {
		return albumNumber;
	}

	public void setAlbumNumber(String albumNumber) {
		this.albumNumber = albumNumber;
	}

	public static void main(String[] args) {
		AlbumAdder aa = new AlbumAdder("Satabdhi", "1974 AD", "2015", "7");
		Boolean result = aa.AddAlbumToDatabase();
		System.out.println(result);
	}

}
