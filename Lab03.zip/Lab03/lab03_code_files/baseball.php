<?php

include_once("Team.php");

function teamComp($a, $b) {
  if($a->getWinPercentage() == $b->getWinPercentage()) {
    return 0;
  } else {
    return ($a->getWinPercentage() < $b->getWinPercentage() ? 1 : -1);
  }
}

  $file_handle = fopen("mlb_nl_2011.txt", "r");

  $teams = array();
  $val = array();

  //TODO: process the text file, creating teams and adding them to the array
  while(!feof($file_handle)) {
    $line = fgets($file_handle);
	$vals = explode(" ", $line);
	//print $vals[0]. "  ". $vals[1]. " "."\n";
	//print $vals[0];
	//echo $vals[1];
    $team = new team($vals[0],$vals[1],$vals[2]);
	array_push($teams, $team);
  }
  fclose($file_handle);
  
$teamInfo = "";
  print "Teams: \n";
  foreach($teams as $team) {
    print $team . "\n";
	printf("%10s, %5.2f", $team->getName(), $team->getWinPercentage());	
  }

  usort($teams, "teamComp");

  print "\n\nSorted Teams: \n";
  foreach($teams as $team) {
    print $team . "\n";
	$teamInfo = $teamInfo.sprintf("%10s, %5.2f", $team->getName(), $team->getWinPercentage()*100). "\n";
  }

  //TODO: output the ordered teams to a file in a different format
  foreach($teams as $team) {
    print "\n\n Team Info";
	$teamInfo = $teamInfo.sprintf("%10s, %5.2f", $team->getName(), $team->getWinPercentage()*100). "\n";
  }
  echo $teamInfo;


?>