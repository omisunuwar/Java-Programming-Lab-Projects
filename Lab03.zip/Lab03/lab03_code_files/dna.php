<?php

  $file_handle = fopen("H1N1nucleotide.txt", "r");

  $dna = "";
  while(!feof($file_handle)) {
    $line = fgets($file_handle);
    $dna .= trim($line);
  }
  fclose($file_handle);
  
  if($argc != 2) {
  print "ERROR: expecting a string subsequence from command line argument\n";
  exit(1);
} else if(!is_string($argv[1])) {
  print "ERROR: command line argument should be an integer\n";
  exit(1);
}

$subsequence = strval($argv[1]);
  
  print $subsequence . " appears " . substr_count($dna, $subsequence) . " times by direct inspection\n";

  $count = 0;
  //TODO: write code to count the number of instances of the subsequence in the dna string
  for($i=0; $i<=(strlen($dna) - strlen($subsequence)); $i++){
	$increment = true;
	for($j=0; $j < strlen($subsequence); $j++){
		if($dna[$i+$j] != $subsequence[$j]){
			$increment = false;
			break;
		}		
	}
	if($increment)
			$count++;	
  }


  print $subsequence . " appears " . $count . " times by logic\n";

?>
