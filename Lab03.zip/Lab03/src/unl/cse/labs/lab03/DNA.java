package unl.cse.labs.lab03;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class DNA {

	public static void main(String args[]) throws FileNotFoundException {

		String fileName = "data/H1N1nucleotide.txt";
		Scanner s = null;
		try {
			s = new Scanner(new File(fileName));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		String dna = "";

		while(s.hasNext()) {
			dna += s.next().trim();
		}
		s.close();
		
		if(args.length < 1) {
			System.err.println("ERROR: expecting a subsequence");
			System.exit(1);
		}

		String subsequence = args[0];
		System.out.println(dna);
		System.out.println(subsequence);
        
		int count = 0; 
		//write code to count the number of times subsequence appears in the dna string
		
		
		if(subsequence.length()<2) {
			System.err.println("Error: type a subsequence of 3 characters");
			System.exit(1);
		}
		
		
		for(int i=0;i<dna.length()-2;i++) {
			if(dna.charAt(i)==subsequence.charAt(0) && dna.charAt(i+1)==subsequence.charAt(1) && dna.charAt(i+2)==subsequence.charAt(2)) {
				count++;
			}
		}

		System.out.println(subsequence + " appears " + count + " times");
///		System.out.println(`${subsequence} appears ${count} times`); Template string/literals
	}
	
}
