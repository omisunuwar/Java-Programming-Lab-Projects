package unl.cse.labs.lab03;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Baseball {

	public static void main(String args[]) {

		String fileName = "data/mlb_nl_2011.txt";
		Scanner s = null;
		try {
			s = new Scanner(new File(fileName));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		Team teams[] = new Team[16];

		// TODO: read in and process the data file, create teams and add them to the
		// array
		/*
		 * try { Scanner ss= new Scanner(new File(filename)); }catch
		 * (FileNotFoundException e) { e.printStackTrace(); }
		 */
		int i = 0;
		while (s.hasNext()) {
			teams[i] = new Team(s.next(), s.nextInt(), s.nextInt());
			i++;
		}

		s.close();

		System.out.println("Teams: ");
		for (Team t : teams) {
			System.out.println(t);
		}

		Arrays.sort(teams, new Comparator<Team>() {
			@Override
			public int compare(Team a, Team b) {
				return a.getName().compareTo(b.getName());
			}

		});


		try {
			PrintWriter pw = new PrintWriter("data/outfile.txt");
			System.out.println("\n\nSorted Teams: ");
			for (Team t : teams) {
				System.out.println(t);

				// TODO: output the team array to a file as specified
				String Nm = String.format("%10s", t.getName());
				String winpr = String.format(" %5.2f", t.getWinPercentage());
				pw.write(Nm + winpr + "\n");
			}
			pw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
