package unl.cse.parking;

public class GarageSimulation {
	public static void main(String[] args) {
		
		Garage safePark = new Garage(10);
		Vehicle herbie = new CompactCar("ABC 123");//Polymorphism -- Vehicle can have instance of Motorbike or SUV or CompactCarf
		safePark.addVehicle(herbie);
		Vehicle v2 = new SUV("QED NEB");
		safePark.addVehicle(v2);
		safePark.addDay();
		safePark.addDay();
		Motorbike v3=new Motorbike("XYZ 321");
		safePark.addVehicle(v3);
		safePark.addDay();
		Vehicle v4=new Motorbike("QT 42");
		safePark.addVehicle(v4);
		Vehicle v5=new CompactCar("FOO 459");
		safePark.addVehicle(v5);
		safePark.addDay();
		safePark.addDay();
		safePark.displayReport();
		safePark.removeVehicle("QT 42");
		safePark.addDay();
		safePark.addDay();
		safePark.displayReport();
		System.out.println("Week2:");
		//Week 2
		safePark.removeVehicle("ABC 123");
		safePark.addDay();
		safePark.addDay();
		safePark.addDay();
		//safePark.displayReport();
		Vehicle v6 = new CompactCar("BAR 560");
		safePark.addVehicle(v6);
		safePark.addDay(4);
		//safePark.removeVehicle("OFP 857");
		//safePark.addDay();
		Vehicle v7= new Truck("ABC 123");
		safePark.addVehicle(v7);
		safePark.addDay();
		safePark.displayReport();
	}
}
