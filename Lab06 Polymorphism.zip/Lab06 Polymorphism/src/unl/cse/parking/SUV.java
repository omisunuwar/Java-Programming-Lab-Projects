package unl.cse.parking;

public class SUV extends Vehicle {

	public SUV(String license) {
		super(license);
		// TODO Auto-generated constructor stub
		//this.type=this.getClass().getSimpleName();
	}
	
	public double calculateFee() {
		double totalFee=0.0;
		int numDays=this.getNumDays();
		if(numDays <= 7) {
			totalFee=numDays*8.0;
		} else {
			totalFee=7*8.0+(numDays-7)*6.0;
		}
		return totalFee;
	}
	
	@Override
	public String getTypeFromInterface() {
		
		return "SUV";
		}
	
}
