package unl.cse.parking;

public class CompactCar extends Vehicle {
	
	//private String type;
	public CompactCar(String license) {
		super(license);
		// TODO Auto-generated constructor stub
		//this.type=this.getClass().getSimpleName();
	}
	
	
	@Override
	public double calculateFee() {
		double totalFee=0.0;
		int numDays = this.getNumDays();
		if(numDays <= 7) {
			totalFee = 6.0 * numDays;
		} else {
			totalFee = 6.0 * 7 + 4.50 * (numDays - 7);
		}
		return totalFee;
	}
	
	@Override
	public String getTypeFromInterface() {
		return "SUV";
	}
}