package unl.cse.parking;

public interface TypeInterface {
	
	
	public String getTypeFromInterface();
	
}