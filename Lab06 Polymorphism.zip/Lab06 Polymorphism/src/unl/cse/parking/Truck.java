package unl.cse.parking;

public class Truck extends Vehicle{

	public Truck(String license) {
		super(license);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getTypeFromInterface() {
		// TODO Auto-generated method stub
		return this.getClass().getSimpleName();
	}

	@Override
	public double calculateFee() {
		// TODO Auto-generated method stub
		return 0;
	}	
}
