package unl.cse.parking;

public abstract class Vehicle implements TypeInterface{

	private final String license;
	private int numDays;
	
	
	// The class constructor
	public Vehicle(String license) {
		this.license = license;
		this.numDays=0;
		
	}
	
	/**
	 * The getter method granting public access to reading the
	 * license plate number. Notice license does not have a
	 * setter since it cannot be modified.
	 */
	public String getLicense() {
		return this.license;
	}
	
	/*public String getDay() {
		return this.day;
	}
	
	public void setDay(String day) {
		this.day=day;
	}*/
	
	public int getNumDays() {
		return this.numDays;
	}
	
	public void setNumDays(int days) {
		this.numDays=days;
	}
	
	public abstract double calculateFee(); 
	
	public abstract String getTypeFromInterface(); 
	
}
