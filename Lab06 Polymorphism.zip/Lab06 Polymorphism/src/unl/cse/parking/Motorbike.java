package unl.cse.parking;

public class Motorbike extends Vehicle{
	

	public Motorbike(String license) {
		super(license);
	
	}
	
	@Override 
	public double calculateFee() {
		double totalFee=0.0;
		int numDays = this.getNumDays();
		if(numDays<=7) {
			totalFee=4.0*numDays;
		} else {
			totalFee=4.0*7+3.0*(numDays-7);
		}
		return totalFee;
	}
	
	
	@Override
	public String getTypeFromInterface() {
		return "Motorbike";
		}
	
}