package unl.cse.library;

public class Author {
	
	private String firstName;   
	private String lastName;
	
	public Author(){
		this.firstName=new String();
		this.lastName=new String();
	}
	
	public String getfirstName() {
		return this.firstName;
	}
	
	public void setfirstName(String firstName) {
		this.firstName=firstName;
	}

	public String getlastName() {
		return this.lastName;
	}
	
	public void setlastName(String lastName) {
		this.lastName=lastName;
	}
	
	public String getformattedAuthor(String firstName, String lastName) {
		return this.lastName+", "+this.firstName;
	}
}
