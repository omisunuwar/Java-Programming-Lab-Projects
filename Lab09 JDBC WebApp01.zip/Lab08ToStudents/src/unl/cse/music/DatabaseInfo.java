package unl.cse.music;

public class DatabaseInfo {

//	public static final String url = "jdbc:mysql://127.0.0.1/lab8schema?autoReconnect=true&useSSL=false";

	public static final String url = "jdbc:mysql://127.0.0.1/lab8schema?characterEncoding=latin1"; 
	public static final String username = "root";
	public static final String password = "MyOracle422!";
}
