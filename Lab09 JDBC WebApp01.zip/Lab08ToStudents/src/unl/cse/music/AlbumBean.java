package unl.cse.music;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AlbumBean {

	@SuppressWarnings("deprecation")
	public Album getDetailedAlbum(int albumId) {

		Album a = new Album();
		/*
		 * 
		 * 
		 * Query the database and get the album with the specified ID, create an Album
		 * object with all details specified
		 */
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (InstantiationException e) {
			System.out.println("InstantiationException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (IllegalAccessException e) {
			System.out.println("IllegalAccessException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}

		Connection conn = null;

		try {
			
			conn = DriverManager.getConnection(DatabaseInfo.url, DatabaseInfo.username, DatabaseInfo.password);

		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}

		String query = "SELECT * FROM Albums where albumId=?";
		BandBean bb = new BandBean();
		Band b = new Band();
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conn.prepareStatement(query);
			ps.setInt(1, albumId); // Set parameter 1(1st ? in query) to albumId. We get albumId from getDetailedAlbum(int albumId)
			rs = ps.executeQuery();
			if (rs.next()) {        // Initially, the cursor is positioned before the first row
				a.setAlbumId(albumId);
				a.setTitle(rs.getString("AlbumTitle"));
				a.setYear(rs.getInt("AlbumYear"));
				a.setAlbumNumber(rs.getInt("AlbumNumber"));
				b = bb.getBand(rs.getInt("BandId"));
				a.setBand(b);

				String query2 = "SELECT a.AlbumTitle, a.AlbumID, s.SongTitle FROM Albums a " + "join AlbumSongs al "
						+ "on al.AlbumID=a.AlbumID " + "join Songs s " + "on s.SongID=al.SongID "
						+ "where a.albumId = ?";

				try {
					PreparedStatement ps2 = conn.prepareStatement(query2);
					ps2.setInt(1, albumId);//1st ? in query to albumId. We get albumId from function call to getDetailedAlbum(int albumId) i.e. this function
					ResultSet rs2 = ps2.executeQuery();

					while (rs2.next()) {
						a.getSongTitles().add(rs2.getString("SongTitle"));
					}
					rs2.close();
				} catch (SQLException e) {
					System.out.println("SQLException: ");
					e.printStackTrace();
					throw new RuntimeException(e);
				}

			}
			rs.close();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}

		try {
			if (rs != null && !rs.isClosed())
				rs.close();
			if (ps != null && !ps.isClosed())
				ps.close();
			if (conn != null && !conn.isClosed())
				conn.close();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}

		return a;
	}

	
	
	@SuppressWarnings("deprecation")
	public List<Album> getAlbums() {

		List<Album> albums = new ArrayList<Album>();

		/*
		 * select * from albums;
		 * 
		 * Query the database and get all the albums in the database with all the
		 * necessary fields, then construct Album objects and add them to the albums
		 * array
		 */

		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance(); 
		} catch (InstantiationException e) {
			System.out.println("InstantiationException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (IllegalAccessException e) {
			System.out.println("IllegalAccessException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}

		Connection conn = null;

		try {
			conn = DriverManager.getConnection(DatabaseInfo.url, DatabaseInfo.username, DatabaseInfo.password); // Connecting
																												// to
																												// Database
																												// url
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}

		
		String query1 = "Select * from Albums";
		PreparedStatement ps = null;
		ResultSet rs = null;

//		Album album = new Album();// Don't create album object here, since you are querying for all the albums, you have to create individual objects
//		Band b = new Band(); //this will create 1 object and all the albums will be pointing to the same object. The last value of the albums will be assigned to all albums
//		BandBean bb1 = new BandBean();
		
		try {
		
			ps = conn.prepareStatement(query1);
			rs = ps.executeQuery();
			while (rs.next()) {
				int albumId = rs.getInt("AlbumID");		
				String title = rs.getString("AlbumTitle");


				Album album = new Album();
				Band b = new Band();
				BandBean bb1 = new BandBean();
				

				album.setAlbumId(albumId);
				album.setTitle(title);
				album.setYear(rs.getInt("AlbumYear"));

				b = bb1.getBand(rs.getInt("bandId"));
				album.setBand(b);
				album.setAlbumNumber(rs.getInt("AlbumNumber"));
			
				
				String query2 = "SELECT a.AlbumTitle, a.AlbumID, s.SongTitle FROM Albums a " + "join AlbumSongs al "
						+ "on al.AlbumID=a.AlbumID " + "join Songs s " + "on s.SongID=al.SongID " + "where a.albumId = ?";
				try {
					PreparedStatement ps2 = conn.prepareStatement(query2);
					ps2.setInt(1, albumId);
					ResultSet rs2 = ps2.executeQuery();

					while (rs2.next()) {

						album.getSongTitles().add(rs2.getString("SongTitle"));
					}

					rs2.close();
					albums.add(album);
				} catch (SQLException e) {
					System.out.println("SQLException: ");
					e.printStackTrace();
					throw new RuntimeException(e);
				}

			}

			rs.close();

		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
		
		try {
			if (rs != null && !rs.isClosed())
				rs.close();
			if (ps != null && !ps.isClosed())
				ps.close();
			if (conn != null && !conn.isClosed())
				conn.close();
		} catch (SQLException e) {
			System.out.println("SQLException: ");
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
		return albums;
	}

	/**
	 * Before exporting to a WAR file and deploying to glassfish, you can test your
	 * method implementations using this main:
	 * 
	 * @param args
	 */
	public static void main(String args[]) {

		System.out.println("Albums: ");
		AlbumBean ab = new AlbumBean();

		for (Album a : ab.getAlbums()) {
			System.out.println("\n" + a.getTitle() + " (id = " + a.getAlbumId() + ")");

			
//			 for(String SongTitle: a.getSongTitles()) {
//			 System.out.println("\t songtitle = "+SongTitle); }
			 

			Album a1 = ab.getDetailedAlbum(a.getAlbumId());
			Band b = a1.getBand();
			if(b != null) {
				System.out.println("\nBandName: "+b.getName());
			}
			for(String SongTitle: a1.getSongTitles()) {
				 System.out.println("\t songtitle = "+SongTitle); }
			 

		}

		
		Album da = null;
		try {
			da = ab.getAlbums().iterator().next(); // iterator of albums i.e each album of albums
		} catch (Exception e) {
			System.out.println("No albums returned in the list");
		}
		if (da != null) {
			System.out.println("\n" + da.getTitle() + " details: ");

			for (String trackTitle : da.getSongTitles()) { // album.getSongTitles
				System.out.println("\t" + trackTitle);
			}
		}
	}
}
