package unl.cse.payroll;

public class Faculty extends Employee {

	
	
	public Faculty(int id, String firstName, String lastName, String type, String position, double hoursPerWeek) {
		super(id, firstName, lastName, type, position, hoursPerWeek);
		// TODO Auto-generated constructor stub
		
	}

	@Override
	public double calculateAnnualSalary() {
		double salary = 0.0;
		if (this.position.equalsIgnoreCase("Assistant-Professor")) {
			salary = 75000;
		} else if (this.position.equalsIgnoreCase("Associate-Professor")) {
			salary = 84000;
		} else if (this.position.equalsIgnoreCase("Professor")) {
			salary = 93000;
		}
		return salary;
	}

}