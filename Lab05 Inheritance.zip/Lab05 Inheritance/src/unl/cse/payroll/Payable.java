package unl.cse.payroll;

public interface Payable {
	
	public double calculateAnnualSalary(); 

}