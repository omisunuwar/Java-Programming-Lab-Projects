package unl.cse.payroll;

import java.io.File;
import java.util.ArrayList;
import java.text.NumberFormat;
import java.util.Scanner;

/**
 * Class designed for testing and executing the correctness of the three classes
 * that you implemented Employee.java, FullTimeEmployee.java,
 * PartTimeEmployee.java
 */
public class Payroll {

	private Employee employees[];
	private int numEmployees = 0;
	
	
	private NumberFormat nf = NumberFormat.getCurrencyInstance(); //NumberFormat is utility class in Java ==> nf.format converts to NumberFormat

	public Payroll() {
		employees = new Employee[100];
		loadFile();
	}

	private void loadFile() {

		try {
			String fileName = "data/employeeRecords.txt";
			File inFile = new File(fileName);
			Scanner s = new Scanner(inFile);
			int i = 0;
	
			while (s.hasNextLine()) {
				String line = s.nextLine();
				String tokens[] = line.split(",");
				Integer id = Integer.parseInt(tokens[0]);
				String lastName = tokens[1];
				String firstName = tokens[2];
				String type = tokens[3]; // Faculty or Staff
				// Faculty: Assistant-Professor, Associate-Professor, or Professor
				// Staff: full-time or part-time
				String position = tokens[4];
				double hoursPerWeek = 0.0;
				try {
				
						hoursPerWeek = Double.parseDouble(tokens[5]);
					
				} catch (Exception e) {
					System.out.println("Cannot convert String to Double");
					e.printStackTrace();
				}

				
				if(type.equalsIgnoreCase("Faculty")) {
					Faculty f = new Faculty(id,firstName,lastName,type,position,hoursPerWeek);
					employees[i]=f;
					i++;
				} else {
					Staff staff = new Staff(id,firstName,lastName,type,position,hoursPerWeek);
					employees[i]=staff;
					i++;
				}
				
			}
			this.numEmployees = i;
			s.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	

	public void printAnnualReport() {
		System.out.println(String.format("%-20s %10s %10s %10s %10s", "Employee Name", "Annual Pay", "FICA", "Hours", "Type"));
		for (int i = 0; i < this.numEmployees; i++) {
			Employee e=employees[i];
			System.out.println(String.format("%-20s %10s %10s %10s %10s", e.getAppendedName(), e.calculateAnnualSalary(),
					nf.format(e.getAnnualFica()), e.getHoursPerWeek(), e.getClass().getSimpleName()));
		}
		
	}

	public static void main(String[] args) {
		Payroll payroll = new Payroll();
		payroll.printAnnualReport();
	}
}
