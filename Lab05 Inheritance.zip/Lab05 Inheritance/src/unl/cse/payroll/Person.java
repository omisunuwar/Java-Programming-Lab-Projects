package unl.cse.payroll;


public interface Person{
	
	public String firstName=null;
	public String lastName=null;
	
	public String getFirstName(); 
	
	public String getLastName();
	
	public String getAppendedName(); 
	
	
}