package unl.cse.payroll;

public class Staff extends Employee {
	
	/*int id;
	String firstName;
	String lastName;
	String type;
	String position;
	double hoursPerWeek;*/
	//String position;
	//double hoursPerWeek;
	
	public Staff(int id, String firstName, String lastName, String type, String position, double hoursPerWeek) {
		super(id, firstName, lastName, type, position, hoursPerWeek);
		// TODO Auto-generated constructor stub
		/*this.id=id;
		this.firstName=firstName;
		this.lastName=lastName;
		this.type=type;
		this.position=position;
		this.hoursPerWeek=hoursPerWeek;*/
		//this.position=position;
		//this.hoursPerWeek=hoursPerWeek;
		
	}

	public double calculateAnnualSalary() {
		double salary=0.0;
		if(this.position.equalsIgnoreCase("part-time"))
			salary=8.5*this.hoursPerWeek*52;
		else
			salary=41000;
		
		return salary;
	}
	
	
}