<?php

  $months = array(
   1 => "January",
   2 => "February",
   3 => "March",
   4 => "April",
   5 => "May",
   6 => "June",
   7 => "July",
   8 => "August",
   9 => "September",
   10 => "October",
   11 => "November",
   12 => "December");
   
   $days = array(
   1 => "1",
   2 => "2",
   3 => "3",
   4 => "4",
   5 => "5",
   6 => "6",
   7 => "7",
   8 => "8",
   9 => "9",
   10 => "10",
   11 => "11",
   12 => "12",
   13 => "13",
   14 => "24",
   15 => "15",
   16 => "16",
   17 => "17",
   18 => "18",
   19 => "19",
   20 => "20",
   21 => "21",
   22 => "22",
   23 => "23",
   24 => "24",
   25 => "25",
   26 => "26",
   27 => "27",
   28 => "28",
   29 => "29",
   30 => "30",
   31 => "31");
?>



<html>
  <head>
    <title>Birthday Program</title>
  </head>

  <body>
    
    <h1>Birthday Calculator Program</h1>

    <p>Greetings.  Please enter your name and your birtday below, then hit
      "submit".</p>
      <form method="post" action="birthday_result.php">
      <table>
        <tr>
          <td>Name:</td>
          <td><input type='text' name='name'/></td>
        </tr>
        <tr>
          <td>Birthday:</td>
          <td>
           <select name="month">
	     <?php 
		foreach($months as $key => $month) {
		  print "<option value='" . $key . "'>" . $month . "</option>\n";
		}
              ?>
            </select>
	    <select name="date">
	      <?php
	        foreach($days as $key => $day) {
				print "<option value='" . $key . "'>" . $day . "</option>\n";
			}
              ?>
	    </select>
            <select name="year">
             <?php
                for($i=1950; $i<=2000; $i++) {
                  print "<option value='" . $i . "'>" . $i . "</option>\n";
                }
              ?>
            </select>
          </td>
        </tr>
        <tr> 
          <td><input type='submit' name='submit' value='Submit'/></td>
        </tr>
      </table>
      </form>
  </body>
</html>
