<?php

include_once("Child.php");

$tom = new Child("Tommy", 14); 
$dick = new Child("Richard", 12);
$harry = new Child("Harold", 21);

$kids = array($tom, $dick, $harry);

//TODO: compute the credits and output a table
echo "Child          Amount\n";
$sum = 0.00;
$amt = 0.00;
$isFirst = true;
foreach($kids as $value){
if($value->getAge()<18){
	if($isFirst)
		$amt = 1000.00;
	else
		$amt = 500.00;
	
	$isFirst = false;
}
else
	$amt = 0.00;

$sum += $amt;

echo $value->__toString().'      '.$amt."\n" ;
}

echo 'Total Credit:   '.$sum ;

?>

<html>
  <head>
    <title>Child Credit Program Title</title>
  </head>

  <body>
    
    <h1>Child Credit Program</h1>
	<table>
        <tr>
          <td>Child</td>
          <td>Amount</td>
        </tr>
		<?php
		$sum = 0.00;
		$amt = 0.00;
		$isFirst = true;
		foreach($kids as $value){
			if($value->getAge()<18){
				if($isFirst)
				$amt = 1000.00;
			else
				$amt = 500.00;
	
			$isFirst = false;
		}
		else
			$amt = 0.00;

		$sum += $amt;
		?>
		<tr>
          <td><?php print $value->__toString(); ?></td>
          <td><?php print $amt; ?></td>
        </tr>
		
		<?php } ?>
		<tr>
          <td>Total Credit:</td>
          <td><?php print $sum; ?></td>
        </tr>
        
	</table>
	
</body>
</html>