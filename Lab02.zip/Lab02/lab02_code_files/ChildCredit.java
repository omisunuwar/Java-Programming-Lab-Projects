package unl.cse.labs.lab02;

public class ChildCredit {

	public static void main(String args[]) {
		Child tom = new Child("Tommy", 14);
		Child dick = new Child("Richard", 12);
		Child harry = new Child("Harold", 21);
		
		Child arr[] = new Child[3];
		arr[0] = tom;
		arr[1] = dick;
		arr[2] = harry;

		//TODO: write a loop to iterate over the elements in the child array 
		//      and output a table as specified
		
	}
}
