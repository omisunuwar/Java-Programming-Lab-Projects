package unl.cse.labs.lab02;

import java.util.Arrays;

public class ChildCredit {

	public static void main(String args[]) {
		Child tom = new Child("Tommy", 2);
		Child dick = new Child("Richard", 18);
		Child harry = new Child("Harold", 19);

		Child arr[] = new Child[3];
		arr[0] = tom;
		arr[1] = dick;
		arr[2] = harry;

		// TODO: write a loop to iterate over the elements in the child array
		// and output a table as specified
		System.out.printf("%-20s %10s", "Child", "Amount\n");
		int j = 0;
		float txcr = 0;
		float total = 0;
		for (int i = 0; i < arr.length; i++) {
			System.out.println(String.format("%-20s", arr[i]));
			System.out.println(arr[i]);

			if (arr[i].getAge() <= 18 && j == 0) {
				txcr = 1000;
				j++;

			} else if (arr[i].getAge() <= 18 && j == 1) {
				txcr = 500;

			} else {
				txcr = 0;
			}
			total += txcr;
			System.out.printf("%-20s $%-10.2f\n", arr[i], txcr);
			

		}
		System.out.printf("%-20s $%10.2f", "Total Credit:", total);

	}
}
