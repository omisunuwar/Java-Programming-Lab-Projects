package unl.cse.labs.lab02;

public class Natural {

	public static void main(String args[]) {
		if(args.length != 1) {
			System.err.println("ERROR: expecting a single integer argument");
			System.exit(1);
		}
		
		Integer n = null;
		try {
			n = Integer.parseInt(args[0]); // converting args[0] from string to integer
		} catch (NumberFormatException nfe) {
			System.err.println("ERROR: expecting a single integer argument");
			System.exit(1);
		}
		
		String zeroToTen[] = new String[11];
		zeroToTen[0] = "zero";
		zeroToTen[1] = "one";
		zeroToTen[2] = "two";
		zeroToTen[3] = "three";
		zeroToTen[4] = "four";
		zeroToTen[5] = "five";
		zeroToTen[6] = "six";
		zeroToTen[7] = "seven";
		zeroToTen[8] = "eight";
		zeroToTen[9] = "nine";
		zeroToTen[10] = "ten";

		//TODO: write a for-loop to compute the sum of 1..n
		int sum=0;
		for(int i=1;i<=n;i++) {
			sum=sum+i;
		}
		System.out.println("Sum: "+sum);

		//TODO: write a while-loop to compute the sum of 1..n
		int total=0;
		int j=1;
		do {
			total+=j;
			j++;
		}while(j<=n);
		System.out.println("Total: "+total);
		
		int sum1 = 0;
		int k = 1;
		while(k <= n) {
			sum1 += k;
			k++;
		}
		System.out.println("Sum1: " + sum1);
		

		//TODO: write an enhanced for-loop to iterate over the zeroToTen array
		String add="";
		for(String s: zeroToTen) {
			add+= s + " ";
		}
		System.out.println(add);


	}

}
